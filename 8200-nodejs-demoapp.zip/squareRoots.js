exports.squareRoots = (number) => {
    return "" + Math.sqrt(number);
}
